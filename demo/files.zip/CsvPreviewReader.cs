using System.Text;

namespace Puma.MDE.Trader.WebUI.Services;

/// <summary>
/// Reads only the beginning of a CSV-like text (header + first N data rows) from a <see cref="TextReader"/>,
/// stopping as soon as the limit is reached. Quote-aware: line breaks inside quoted fields do not end a row.
/// </summary>
internal static class CsvPreviewReader
{
    public static async Task<(string Text, bool IsTruncated)> ReadAsync(
        TextReader reader,
        int maxDataRows,
        int maxChars,
        CancellationToken cancellationToken)
    {
        var maxRecords = maxDataRows + 1; // header + data rows
        var sb = new StringBuilder();
        var buffer = new char[8192];
        var inQuotes = false;
        var records = 0;
        var limitReached = false;

        while (true)
        {
            var read = await reader.ReadAsync(buffer.AsMemory(), cancellationToken);
            if (read == 0)
                return (sb.ToString(), false);

            for (var i = 0; i < read; i++)
            {
                var c = buffer[i];

                if (limitReached)
                {
                    // Row limit already reached: the content is truncated only if something meaningful follows.
                    if (!char.IsWhiteSpace(c))
                        return (sb.ToString(), true);
                    continue;
                }

                sb.Append(c);

                if (c == '"')
                {
                    inQuotes = !inQuotes; // an escaped quote ("") toggles twice, so it is handled correctly
                }
                else if (c == '\n' && !inQuotes && ++records >= maxRecords)
                {
                    limitReached = true;
                }

                if (sb.Length >= maxChars)
                    return (sb.ToString(), true);
            }
        }
    }
}
