namespace Puma.MDE.Trader.WebUI.Services.Data;

/// <summary>
/// First rows of a request payload plus information about the full payload.
/// </summary>
/// <param name="Format">Content type stored with the message (e.g. CSV).</param>
/// <param name="Text">Header + first rows of the payload.</param>
/// <param name="IsTruncated">True when the payload contains more data than <paramref name="Text"/>.</param>
/// <param name="TotalLength">Length of the full payload, in characters.</param>
public sealed record PubRequestPayloadPreview(string? Format, string Text, bool IsTruncated, long TotalLength);
